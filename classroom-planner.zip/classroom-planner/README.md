# Classroom Planner

Lektionsplaneringsapp med Google Classroom-integration för matematikundervisning i åk 8.

## Arkitektur

Tre-rings-modell med beroenden som alltid pekar inåt:

```
Ring 3 — Ytor (web, dashboards, Classroom Add-on)
Ring 2 — Adaptrar (Google, AI, Socrative, Magma, lokal lagring)
Ring 1.5 — App Services (use cases, transaktioner, DI)
Ring 1 — Ren kärna (packages/core) — NOLL externa dependencies
```

## Kommandon

```bash
npm install          # Installera beroenden
npm test             # Lint + typecheck + tester (allt)
npm run typecheck    # Enbart TypeScript
npm run lint         # Enbart ESLint (invarianter I1/I2)
npm run test:unit    # Enbart Vitest
```

## Paketstruktur

```
classroom-planner/
  packages/
    core/                 # Ring 1: ren domän (Sprint 1–4)
    app-services/         # Ring 1.5: use cases (Sprint 5)
    adapters-local/       # Ring 2: lokal lagring (Sprint 5)
    adapters-google/      # Ring 2: Google Classroom, Drive, Docs, Forms (Sprint 8–11)
    adapters-ai/          # Ring 2: AI-provider-abstraktion (Sprint 17)
    adapters-socrative/   # Ring 2: Socrative-import (Sprint 15)
    adapters-magma/       # Ring 2: Magma-import (Sprint 15)
    web/                  # Ring 3: Vite-UI (Sprint 6)
    dashboards/           # Ring 3: SuperTeach-vyer (Sprint 16)
```

## Sprint-status

| Sprint | Innehåll | Status |
|--------|----------|--------|
| 1 | Projektgrund, monorepo, I1/I2, felmodell | ✅ Klar |
| 2 | Domäntyper (LessonContent, SourceRef) | ⬜ Ej påbörjad |
| 3 | Ren kärnlogik (versionering, BAM, sök) | ⬜ Ej påbörjad |
| 4 | Planeringsmotor | ⬜ Ej påbörjad |
| 5 | App-services / use cases | ⬜ Ej påbörjad |
| 6 | Lokal webbapp (B1–B36 paritet) | ⬜ Ej påbörjad |
| ... | ... | ... |
| 22 | SuperTeach + AI samverkan | ⬜ Ej påbörjad |

## Invarianter

| ID | Regel | Kontroll |
|----|-------|----------|
| I1 | Core importerar aldrig från yttre ringar | ESLint |
| I2 | Core saknar google/fetch/window/document/localStorage | ESLint |
| I3 | LessonVersion append-only | Tester |
| I4 | Publicering idempotent via ExternalRef | Tester |
| I5 | Läroplan icke-blockerande | Tester |
| I6 | AI utbytbar via config | Tester |
| I7 | AI-bedömning = förslag tills lärargranskning | Tester |
