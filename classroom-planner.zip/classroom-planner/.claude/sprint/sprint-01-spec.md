# Sprint 1: Projektgrund

**Status:** Ej påbörjad
**Mål:** Fungerande TypeScript-monorepo med maskinkontrollerade arkitekturinvarianter,
felmodell och dokumentkuvert med schemaVersion.

## Leverabler

| # | Fil | Innehåll |
|---|-----|----------|
| 1 | `package.json` | Rot, workspaces: `["packages/*"]` |
| 2 | `tsconfig.base.json` | strict, ES2020, ESNext, noUncheckedIndexedAccess |
| 3 | `tsconfig.json` | Rot, references till core |
| 4 | `vitest.config.ts` | Testroot = packages, alias @planner/core |
| 5 | `eslint.config.mjs` | I1+I2 som error (rött bygge vid brott) |
| 6 | `packages/core/package.json` | @planner/core, noll dependencies |
| 7 | `packages/core/tsconfig.json` | extends base, composite |
| 8 | `packages/core/src/errors.ts` | DomainError, ValidationError, SchemaVersionError |
| 9 | `packages/core/src/document.ts` | PlannerDocumentV1, migrate, prepareForSave, roundTrip |
| 10 | `packages/core/src/index.ts` | Re-export av allt publikt |
| 11 | `packages/core/test/smoke.test.ts` | 5 smoke-tester |
| 12 | `packages/core/test/document.test.ts` | 4 C.12-tester + 10 edge cases |
| 13 | `packages/core/test/invariants.test.ts` | Programmatisk I1/I2-kontroll |

## Testfacit C.12

| # | Test | Assertion |
|---|------|-----------|
| 1 | Round-trip bevarar schemaVersion | create → serialize → roundTrip → schemaVersion === 1 |
| 2 | Nyare schemaVersion → SchemaVersionError | migrateDocument({schemaVersion:999}) throws |
| 3 | v1→v1 identitetsmigrering no-op | samma fältvärden, inga tillägg/borttagningar |
| 4 | updatedAt sätts vid save | prepareForSave med ny Clock → updatedAt uppdaterad, createdAt orörd, original ej muterat |

## Förbjudet i Sprint 1
- LessonContent, LessonTemplate, ScheduledLesson, Book, Concept
- Classroom, Google Docs, SuperTeach, AI
- UI-kod, React, HTML
- TODO-stubbar, placeholder-funktioner
- Externa npm-dependencies i packages/core
- `any` i TypeScript

## Definition of Done
1. `npm test` (lint + typecheck + vitest) = grönt
2. ESLint fångar I2-brott (verifiera med temporär testfil)
3. packages/core/package.json: `dependencies: {}`
4. Alla 4 C.12-tester + 10 edge cases + 5 smoke + invarianttester gröna
5. Verifieringssubagent: GODKÄND
