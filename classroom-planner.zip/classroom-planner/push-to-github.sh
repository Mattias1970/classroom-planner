#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════
# push-to-github.sh
#
# Skapar ett GitHub-repo och pushar classroom-planner dit.
# Kräver GitHub CLI (gh) installerat och inloggat.
#
# Installation av gh:
#   macOS:  brew install gh
#   Ubuntu: sudo apt install gh
#   Sedan:  gh auth login
#
# Användning (kör från inuti classroom-planner/):
#   chmod +x push-to-github.sh
#   ./push-to-github.sh
# ═══════════════════════════════════════════════════════════════

set -euo pipefail

REPO_NAME="classroom-planner"
DESCRIPTION="Lektionsplaneringsapp med Google Classroom-integration — TypeScript monorepo"

# ── Kontrollera att gh är installerat ─────────────────────────
if ! command -v gh &>/dev/null; then
  echo "❌  GitHub CLI (gh) saknas."
  echo "    macOS:  brew install gh"
  echo "    Ubuntu: sudo apt install gh"
  echo "    Logga sedan in: gh auth login"
  exit 1
fi

# ── Kontrollera inloggning ─────────────────────────────────────
if ! gh auth status &>/dev/null; then
  echo "❌  Inte inloggad i GitHub CLI."
  echo "    Kör: gh auth login"
  exit 1
fi

GITHUB_USER=$(gh api user --jq .login)
echo "✅  Inloggad som: $GITHUB_USER"

# ── Git init om det behövs ─────────────────────────────────────
if [ ! -d ".git" ]; then
  git init
  echo "✅  Git initierat"
fi

# ── Initial commit ─────────────────────────────────────────────
git add -A
if git diff --cached --quiet; then
  echo "ℹ️   Inga ändringar att commita"
else
  git commit -m "Sprint 1: Projektgrund — monorepo, I1/I2, felmodell, PlannerDocumentV1

- TypeScript monorepo med npm workspaces
- ESLint maskinkontrollerar I1 (beroenderiktning) och I2 (ren core)
- DomainError → ValidationError → SchemaVersionError arvshierarki
- PlannerDocumentV1 med schemaVersion 1 och identitetsmigrering
- createDocument, migrateDocument, prepareForSave, roundTrip
- 30 tester — alla gröna (lint + typecheck + vitest)"
  echo "✅  Commit skapad"
fi

# ── Skapa GitHub-repo ──────────────────────────────────────────
echo "🚀  Skapar GitHub-repo: $GITHUB_USER/$REPO_NAME ..."

gh repo create "$REPO_NAME" \
  --private \
  --description "$DESCRIPTION" \
  --source . \
  --remote origin \
  --push

echo ""
echo "✅  Repot är uppe på GitHub!"
echo "    https://github.com/$GITHUB_USER/$REPO_NAME"
echo ""
echo "Nästa steg:"
echo "  cd classroom-planner"
echo "  claude"
echo "  [klistra in Sprint 2-prompten]"
